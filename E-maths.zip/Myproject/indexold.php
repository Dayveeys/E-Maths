<!DOCTYPE html>
<html lang="en">
<head>
<title>E-Maths || Welcome</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Vegur_700.font.js"></script>
<script type="text/javascript" src="js/Vegur_400.font.js"></script>
<script type="text/javascript" src="js/Vegur_300.font.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/tms-0.3.js"></script>
<script type="text/javascript" src="js/tms_presets.js"></script>
<script type="text/javascript" src="js/backgroundPosition.js"></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.box1 figure{behavior:url("js/PIE.htc");}</style>
<![endif]-->

</head>
<body id="page1">
<div class="body1">
  <div class="main">
    <!-- header-->
    <?php include_once ('header.php'); ?>
     <div class="slider">
        <ul class="items">
          <li> <img src="images/img1.jpg" alt="">
            <div class="banner">
              <div class="wrapper"><span>“YOU can Learn</em></span></div>
              <div class="wrapper"><strong>Secondary School<em> Maths</em> For Free”</strong></div>
            </div>
          </li>
          <li> <img src="images/img2.jpg" alt="">
            <div class="banner">
              <div class="wrapper"><span>“LEARN Conveniently</span></div>
              <div class="wrapper"><strong>From ANYWHERE”</strong></div>
            </div>
          </li>
          <li> <img src="images/img3.jpg" alt="">
            <div class="banner">
              <div class="wrapper"><span>“LEARNING Mathematics</span></div>
              <div class="wrapper"><strong>Becomes so EASY”</strong></div>
            </div>
          </li>
        </ul>
        <ul class="pagination">
          <li id="banner1"><a href="reg.php">Learn<span>for free</span></a></li>
          <li id="banner2"><a href="app/login.php">learn<span>from home</span></a></li>
          <li id="banner3"><a href="app/studportal/login.php">Maths<span>is fun</span></a></li>
        </ul>
      </div>
      <!-- header-->
    <!-- content -->
    <article id="content">
      <div class="wrapper">
        <h3>Mission</h3>
        <p class="quot"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid- idunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exerci- tation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse.<img src="images/quot2.png" alt=""> </p>
      </div>
    </article>
    <!-- / content -->
    <!-- footer -->
    <footer>
      <div class="wrapper"> <a href="index.html" id="footer_logo"><span>E-</span>Maths</a>
      </div>
      <div class="wrapper">
        <nav>
          <ul id="footer_menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="mission.html">Login</a></li>
            <li><a href="news.html">Sign Up</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </nav>
        <div class="tel"><span>+234 70</span>6 896 9591</div>
      </div>
      <div id="footer_text" style="color: #fff;">Copyright &copy; <script>var y = new Date(); document.write(y.getFullYear()+" ");
      </script> 
        E-maths</strong> All rights reserved | Design by Umeoka Davis</div>
    </footer>
    <!-- / footer -->
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
<script type="text/javascript">
$(window).load(function () {
    $('.slider')._TMS({
        preset: 'zabor',
        easing: 'easeOutQuad',
        duration: 800,
        pagination: true,
        banners: true,
        waitBannerAnimation: false,
        slideshow: 6000,
        bannerShow: function (banner) {
            banner.css({
                right: '-700px'
            }).stop().animate({
                right: '0'
            }, 600, 'easeOutExpo')
        },
        bannerHide: function (banner) {
            banner.stop().animate({
                right: '-700'
            }, 600, 'easeOutExpo')
        }
    })
    $('.pagination li').hover(function () {
        if (!$(this).hasClass('current')) {
            $(this).find('a').stop().animate({
                backgroundPosition: '0 0'
            }, 600, 'easeOutExpo', function () {
                $(this).parent().css({
                    backgroundPosition: '-20px 0'
                })
            });
        }
    }, function () {
        if (!$(this).hasClass('current')) {
            $(this).css({
                backgroundPosition: '0 0'
            }).find('a').stop().animate({
                backgroundPosition: '-250px 0'
            }, 600, 'easeOutExpo');
        }
    })
})
</script>
</body>
</html>