<!-- header -->
    <header>
      <div class="wrapper">
        <img src="images/logo.png" alt="logo"/>
        <nav>
          <ul id="top_nav">
            <li><a href="index.php"><img src="images/top_icon1.gif" alt=""></a></li>
            <li class="end" style="background-color: blue;"><a style="color: #fff;padding: 5px;" href="app/login.php">Admin</a></li>
          </ul>
        </nav>
        <nav>
          <ul id="menu">
            <li id="menu_active"><a href="index.php">Home</a></li>
            <li><a href="app/studportal/login.php">Student Login</a></li>
            <li><a href="app/login.php">Tutor login</a></li>
            <li><a href="reg.php">sign up</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </nav>
      </div>
    </header>
    <!-- / header -->