<?php
include_once 'phpfiles/global.php';

checknotlogged();

if ($admin_level != 'super') {
  header("location: index.php");
}

$title = "Student Details";
$active4 = "bg-white";


include_once 'header.php' ?>

<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>

  <div class="table-responsive">
    <table class="table table-striped table-hover">
      <tr>
        <th>S/N</th>
        <th>Reg number</th>
        <th>Fullname</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Programme</th>
        <th>Date of birth</th>
        <th>Phone number</th>
        <th>Address</th>
        <th>State</th>
        <th>LGA</th>
        <th>Nationality</th>
      </tr>

      <?php
        $sql = "select * from students";
        $result = mysqli_query($connect, $sql);
        if ($result) {
          $sn = 0;
          while ($found = mysqli_fetch_array($result)) {
            $sn++;
            $id = $found['id'];
            $reg_no = $found['reg_no'];
            $firstname = $found['firstname'];
            $lastname = $found['lastname'];
            $othernames = $found['othernames'];
            $email = $found['email'];
            $gender = $found['gender'];
            $programme = $found['programme'];
            $dob = $found['dob'];
            $phone = $found['phone'];
            $address = $found['address'];
            $state = $found['state'];
            $lga = $found['lga'];
            $nationality = $found['nationality'];

            echo "
              <tr>
                <td>{$sn}</td>
                <td>{$reg_no}</td>
                <td>{$firstname} {$lastname} {$othernames}</td>
                <td>{$email}</td>
                <td>{$gender}</td>
                <td>{$programme}</td>
                <td>{$dob}</td>
                <td>{$phone}</td>
                <td>{$address}</td>
                <td>{$state}</td>
                <td>{$lga}</td>
                <td>{$nationality}</td>
              </tr>
            ";
          }
        }
      ?>
    </table>
  </div>

</div>

<?php include_once 'footer.php' ?>
