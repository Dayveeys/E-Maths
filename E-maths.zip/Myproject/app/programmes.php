<?php
include_once 'phpfiles/global.php';

checknotlogged();

$title = "Programmes";
$active7 = "bg-white";

$add = $add2 = "";
$home = "in active";
$menu1 = "";

if (isset($_GET['success'])) {
  $notify = "<span class=\"alert-success w3-padding\">Added successfully!</span>";
}

if (isset($_POST['submit'])) {
  $home = "";
  $menu1 = "in active";

  $add = checkinput($_POST['programme']);
  $hod = checkinput($_POST['hod']);
  $faculty = checkinput($_POST['faculty']);

  if (!empty($add)) {
    if (preg_match("/^[a-zA-Z0-9& ]*$/",$add)) {
      if ($hod != 'choose') {
        if ($faculty != 'choose') {
          $sql = "select * from programmes where programmes = '$add'";
          $query = mysqli_query($connect, $sql);
          if (!mysqli_num_rows($query) > 0) {
            $sql = "insert into programmes (programmes, hod, faculty)
            values ('$add', '$hod', '$faculty')";
            $check = mysqli_query($connect, $sql);
            if ($check) {
              header ('location: programmes.php?success');
            }
          }else {
            $notify = "<span class=\"alert-danger w3-padding\">Already added!</span>";
          }
        }else {
          $notify = "<span class=\"alert-danger w3-padding\">Please choose faculty!</span>";
        }
      }else {
        $notify = "<span class=\"alert-danger w3-padding\">Please choose HOD!</span>";
      }
    }else {
      $notify = "<span class=\"alert-danger w3-padding\">Enter a valid programme name!</span>";
    }
  }else {
  $notify = "<span class=\"alert-danger w3-padding\">Field cannot be empty!</span>";
  }
}

if (isset($_POST['submit2'])) {
  $home = "in active";
  $menu1 = "";

  $add2 = checkinput($_POST['faculty']);

  if (!empty($add2)) {
    if (preg_match("/^[a-zA-Z0-9& ]*$/",$add2)) {
      $sql = "select * from faculty where faculty = '$add2'";
      $query = mysqli_query($connect, $sql);
      if (!mysqli_num_rows($query) > 0) {
        $sql = "insert into faculty (faculty)
        values ('$add2')";
        $check = mysqli_query($connect, $sql);
        if ($check) {
          header ('location: programmes.php?success');
        }
      }else {
        $notify = "<span class=\"alert-danger w3-padding\">Already added!</span>";
      }
    }else {
      $notify = "<span class=\"alert-danger w3-padding\">Enter a valid faculty name!</span>";
    }
  }else {
  $notify = "<span class=\"alert-danger w3-padding\">Field cannot be empty!</span>";
  }
}

include_once 'header.php' ?>

<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>

  <ul class="nav nav-tabs">
    <li class="<?php echo $home; ?>"><a data-toggle="tab" href="#home">Add Faculty</a></li>
    <li class="<?php echo $menu1; ?>"><a data-toggle="tab" href="#menu1">Add Programme</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade <?php echo $home; ?>">
      <br>
      <?php
        if ($admin_level == 'super') {
          echo '
          <h5 class="w3-margin-bottom">Add faculty:</h5>
          <form action="programmes.php" method="post">
            <div class="row">
              <div class="col-sm-12">
                <label for="programme">Faculty:</label>
                <input class="form-control w3-margin-bottom" type="text" name="faculty" value="'.$add2.'" placeholder="Eg: Law">
              </div>
            </div>
            <input class="btn bg-color2 w3-text-white" type="submit" name="submit2" value="Submit">
          </form>

          <br><br>
          ';
        }
      ?>

      <div class="table-responsive">
        <table class="table table-striped table-hover">
          <tr>
            <th>S/N</th>
            <th>Faculties</th>
          </tr>

          <?php
            $sql = "select * from faculty";
            $result = mysqli_query($connect, $sql);
            if ($result) {
              $sn = 0;
              while ($found = mysqli_fetch_array($result)) {
                $sn++;
                $id = $found['id'];
                $faculty = $found['faculty'];

                echo "
                  <tr>
                    <td>{$sn}</td>
                    <td>{$faculty}</td>
                  </tr>
                ";
              }
            }
          ?>
        </table>
      </div>
    </div>

    <div id="menu1" class="tab-pane fade <?php echo $menu1; ?>">
      <br>
      <?php
        if ($admin_level == 'super') {
          echo '
          <h5 class="w3-margin-bottom">Add programme:</h5>
          <form action="programmes.php" method="post">
            <div class="row">
              <div class="col-sm-4">
                <label for="programme">Programme:</label>
                <input class="form-control w3-margin-bottom" type="text" name="programme" value="'.$add.'" placeholder="Eg: Computer Science">
              </div>
              <div class="col-sm-4">
                <label for="hod">HOD:</label>
                <select class="form-control w3-margin-bottom" name="hod">
                  <option value="choose">-- choose --</option>
                    ';
                    $sql = "select * from reg_admin where level = 'staff'";
                    $query = mysqli_query($connect, $sql);
                    while ($found = mysqli_fetch_array($query)) {
                      $fullname = $found['fullname'];

                      echo "
                        <option value=\"$fullname\">$fullname</option>
                      ";
                    }
                    echo '
                </select>
              </div>
              <div class="col-sm-4">
                <label for="faculty">Faculty:</label>
                <select class="form-control w3-margin-bottom" name="faculty">
                  <option value="choose">-- choose --</option>
                    ';
                    $sql = "select * from faculty";
                    $query = mysqli_query($connect, $sql);
                    while ($found = mysqli_fetch_array($query)) {
                      $faculty = $found['faculty'];

                      echo "
                        <option value=\"$faculty\">$faculty</option>
                      ";
                    }
                    echo '
                </select>
              </div>
            </div>
            <input class="btn bg-color2 w3-text-white" type="submit" name="submit" value="Submit">
          </form>

          <br><br>
          ';
        }
      ?>

      <div class="table-responsive">
        <table class="table table-striped table-hover">
          <tr>
            <th>S/N</th>
            <th>Programmes</th>
            <th>Head of Department</th>
            <th>Faculty</th>
          </tr>

          <?php
            $sql = "select * from programmes";
            $result = mysqli_query($connect, $sql);
            if ($result) {
              $sn = 0;
              while ($found = mysqli_fetch_array($result)) {
                $sn++;
                $id = $found['id'];
                $programme = $found['programmes'];
                $hod = $found['hod'];
                $faculty = $found['faculty'];

                echo "
                  <tr>
                    <td>{$sn}</td>
                    <td>{$programme}</td>
                    <td>{$hod}</td>
                    <td>{$faculty}</td>
                  </tr>
                ";
              }
            }
          ?>
        </table>
      </div>
  </div>

</div>

<?php include_once 'footer.php' ?>
