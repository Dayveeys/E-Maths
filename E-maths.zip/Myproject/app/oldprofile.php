<?php
include_once 'phpfiles/global.php';

checknotlogged();

$title = "My Profile";

if (isset($_POST['edit'])) {
  $admin_fullname = checkinput($_POST['admin_fullname']);
  $admin_security_key = checkinput($_POST['admin_security_key']);
  $admin_password = checkinput($_POST['admin_password']);
  $c_password = checkinput($_POST['c_password']);
  $admin_email = checkinput($_POST['admin_email']);
  $admin_gender = checkinput($_POST['admin_gender']);
  $admin_programme = checkinput($_POST['admin_programme']);
  $admin_phone = checkinput($_POST['admin_phone']);
  $admin_address = checkinput($_POST['admin_address']);
  $admin_qualification = checkinput($_POST['admin_qualification']);

  if (!empty($admin_fullname)) {
    if (!empty($admin_security_key)) {
      if (!empty($admin_password)) {
        if (!empty($admin_email)) {
          if ($admin_gender != 'choose') {
            if ($admin_programme != 'choose') {
              if (!empty($admin_phone)) {
                if (!empty($admin_address)) {
                  if (!empty($admin_qualification)) {
                    if (filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
                      if (preg_match("/^[0-9]*$/",$admin_phone)) {
                        if (preg_match("/^[a-zA-Z0-9-+,. ]*$/",$admin_address)) {
                          if ($admin_password == $c_password) {
                            $admin_password = sha1($admin_password);
                            $sql = "update reg_admin set fullname = '$admin_fullname', security_key = '$admin_security_key', password = '$admin_password', email = '$admin_email', gender = '$admin_gender', programme = '$admin_programme', phone = '$admin_phone', address = '$admin_address', qualification = '$admin_qualification' where id = '$admin_id' limit 1";
                            if (mysqli_query($connect, $sql)) {
                              $notify = "<span class=\"alert-success w3-padding\">Updated successfully!</span>";
                            }
                          }else {
                            $notify = "<span class=\"alert-danger w3-padding\">Confirm password does not match!</span>";
                          }
                        }else {
                          $notify = "<span class=\"alert-danger w3-padding\">Please type a valid address!</span>";
                        }
                      }else {
                        $notify = "<span class=\"alert-danger w3-padding\">Please type a valid phone number!</span>";
                      }
                    }else {
                      $notify = "<span class=\"alert-danger w3-padding\">Please type a valid email!</span>";
                    }
                  }else {
                    $notify = "<span class=\"alert-danger w3-padding\">Qualification field is required!</span>";
                  }
                }else {
                  $notify = "<span class=\"alert-danger w3-padding\">Address field is required!</span>";
                }
              }else {
                $notify = "<span class=\"alert-danger w3-padding\">Phone field is required!</span>";
              }
            }else {
              $notify = "<span class=\"alert-danger w3-padding\">Please choose your programme!</span>";
            }
          }else {
            $notify = "<span class=\"alert-danger w3-padding\">Please choose your gender!</span>";
          }
        }else {
          $notify = "<span class=\"alert-danger w3-padding\">Email field is required!</span>";
        }
      }else {
        $notify = "<span class=\"alert-danger w3-padding\">Password field is required!</span>";
      }
    }else {
      $notify = "<span class=\"alert-danger w3-padding\">Security key field is required!</span>";
    }
  }else {
    $notify = "<span class=\"alert-danger w3-padding\">Full name field is required!</span>";
  }
}
?>
<?php require_once("includes/commonlinks.php"); ?>
 
      <!--header-->
      <?php require_once("includes/header.php"); ?>
      <!--header-->

      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once("includes/aside.php"); ?>
      <!-- /.sidebar -->
<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>

  <div class="table-responsive">
    <table class="table table-striped table-hover">
      <tr>
        <th>S/N</th>
        <th>Fullname</th>
        <th>Username</th>
        <th>Security Key</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Programme</th>
        <th>Phone number</th>
        <th>Address</th>
        <th>Qualification</th>
        <th>Salary</th>
      </tr>

      <?php
        $sn = 1;
        if ($admin_salary == "") {
          $admin_salary = "-";
        }
        echo "
          <tr>
            <td>{$sn}</td>
            <td>{$admin_fullname}</td>
            <td>{$admin_username}</td>
            <td>{$admin_security_key}</td>
            <td>{$admin_email}</td>
            <td>{$admin_gender}</td>
            <td>{$admin_programme}</td>
            <td>{$admin_phone}</td>
            <td>{$admin_address}</td>
            <td>{$admin_qualification}</td>
            <td>{$admin_salary}</td>
          </tr>
        ";
      ?>
    </table>
  </div>

  <hr>

  <h5>Edit Profile</h5>

  <form action="profile.php" method="post">
    <div class="col-sm-4">
      <div class="form-group">
        <label for="admin_fullname">Full Name</label>
        <input class="form-control" type="text" name="admin_fullname" value="<?php echo $admin_fullname; ?>">
      </div>
      <div class="form-group">
        <label for="admin_security_key">Security Key</label>
        <input class="form-control" type="text" name="admin_security_key" value="<?php echo $admin_security_key; ?>">
      </div>
      <div class="form-group">
        <label for="admin_password">Password</label>
        <input class="form-control" type="password" name="admin_password" value="">
      </div>
      <div class="form-group">
        <label for="c_password">Confirm Password</label>
        <input class="form-control" type="password" name="c_password" value="">
      </div>
    </div>

    <div class="col-sm-4">
      <div class="form-group">
        <label for="admin_email">Email</label>
        <input class="form-control" type="text" name="admin_email" value="<?php echo $admin_email; ?>">
      </div>
      <div class="form-group">
        <label for="gender">Gender</label>
        <select class="form-control w3-margin-bottom" name="admin_gender">
          <option value="choose">-- Choose --</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>
      <div class="form-group">
        <label for="admin_programme">Programme</label>
        <select class="form-control w3-margin-bottom" name="admin_programme">
          <option value="choose">-- choose --</option>
          <?php
            if ($admin_level == 'super') {
              echo "<option value=\"All\">All</option>";
            }else {
              $sql = "select * from programmes";
              $query = mysqli_query($connect, $sql);
              while ($found = mysqli_fetch_array($query)) {
                $programme = $found['programmes'];

                echo "
                  <option value=\"$programme\">$programme</option>
                ";
              }
            }
          ?>
        </select>
      </div>
    </div>

    <div class="col-sm-4">
      <div class="form-group">
        <label for="admin_phone">Phone number</label>
        <input class="form-control" type="text" name="admin_phone"  value="<?php echo $admin_phone; ?>">
      </div>
      <div class="form-group">
        <label for="admin_address">Address</label>
        <input class="form-control" type="text" name="admin_address" value="<?php echo $admin_address; ?>">
      </div>
      <div class="form-group">
        <label for="admin_qualification">Qualification</label>
        <input class="form-control" type="text" name="admin_qualification" value="<?php echo $admin_qualification; ?>">
      </div>
    </div>
    <div class="col-sm-12">
      <div class="form-group">
        <input class="btn bg-color2 hover-opacity w3-text-white" type="submit" name="edit" value="Edit">
      </div>
    </div>
  </form>

</div>

<?php include_once 'footer.php' ?>
