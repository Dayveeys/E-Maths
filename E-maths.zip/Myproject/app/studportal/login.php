<?php
include_once 'phpfiles/global.php';

checkstudentlogged();

$title = "Student Portal Login";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = checkinput($_POST['email']);
  $password = checkinput($_POST['password']);

  if (!empty($email) && !empty($password)){
    $password = md5($password);
    $sql = "select id from students where email = '$email' and password ='$password' limit 1";
    $result = mysqli_query($connect, $sql);
    if ($result) {
      if (mysqli_num_rows($result) > 0 ) {
        $found = mysqli_fetch_array($result);

        $_SESSION['student_bigdata'] = $found['id'];
        header("location: index.php");
      }else {
        $error = "Incorrect email or password";
      }
    }

  }else {
    $error = "All fields are required!";
  }
}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link href="images/favicon.ico" rel="shortcut icon" media="all">
    <title>Student Login :: E-Maths</title>

    <!-- Bootstrap CSS -->    
    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css2/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="plugins/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css2/elegant-icons-style.css" rel="stylesheet" />
    <link href="css2/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css2/style2.css" rel="stylesheet">
    <link href="css2/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="" style="background-image: url('images/bg.jpg'); background-repeat: no-repeat;">

    <div class="container">

        <div class="col-md-12">
              <h2 style="color:#fff; font-size:40px; text-align:center;">Students Login</h2>
        </div>
      
      <form style="margin-top:0%;" class="login-form" action="login.php" method="post">        
        <div class="login-wrap">
            <p class="login-img"><i class="fa fa-lock"></i></p>
            <p style="color: red; text-align: center;"><?php echo $error;  ?></p>
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user"></i></span>
              <input type="email" class="form-control" name="email" placeholder="E-mail" autofocus required>
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-key"></i></span>
                <input type="password" class="form-control" placeholder="Password" name="password" value="" id="pass" required="">
            </div>
            <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
                <!-- <span class="pull-right"> <a href="#"> Forgot Password?</a></span> -->
            </label>
            <button name="login" class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
        </div>
      </form>
      
    </div><br>
    <div class="col-md-6 center-block">
      <a class="btn btn-primary pull-right" href="../../reg.php">Click Here to Signup</a>
    </div>
    <div class="col-md-6 center-block">
      <a class="btn btn-primary" href="../../index.php"><i class="fa fa-home"></i> Go back to Home</a>
    </div><br><br>
    <div class="col-md-12 w3_agile-copyright text-center">
        <hr><p style="text-align:center; color:#fff;">
            &copy; <script>var y = new Date(); document.write(y.getFullYear() + " ");</script>
            All rights reserved | Design by Davis Umeoka
        </p>
    </div>

  </body>
</html>
