<?php require_once("includes/dbkey.php"); ?>
<?php
include_once 'phpfiles/global.php';

// if (isset($_GET['res']) && $_GET['res'] !== '' && $_GET['res'] == 'yes') {

//     $msg ='<h4 id="delsucs" class="pull-right" style="color:white; padding:15px; width:300px; background-color:green; text-align:center; border-radius:5px;">Deleted successfully!</h4>';
//   }
 $passport='';

  if (isset($_GET['ID']) && $_GET['ID'] !== '') {
    $ID = $_GET['ID'];
    $passport = $_GET["passport"];

    
    $passportDir = 'uploads/courseware/';
    $passportFullDir = $passportDir.$passport;

 

  $delSQl = "DELETE FROM videos WHERE ID = '$ID'";
  mysqli_select_db($connect, $dbname);
  $successDel = mysqli_query($connect, $delSQl);

  if ($successDel) {
    if (unlink($passportFullDir)) {
      $msg ='<h4 id="delsucs" class="pull-right" style="color:white; padding:15px; width:300px; background-color:green; text-align:center; border-radius:5px;">Deleted successfully!</h4>';
    }
    
   
  }else{
    $msg ='<h4 id="" class="pull-right" style="color:white; padding:15px; width:300px; background-color:green; text-align:center; border-radius:5px;">Not deleted successfully!</h4>';
    echo mysql_error();
  }

    
  }

?>



<?php
  //declare variables empty
  $name = $phone = $email = "";
  
  //declare test_input function
  function test_input($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
  
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    //declare the variables
    
    $phone = test_input($_POST["topic"]);
    $module = test_input($_POST["module"]);
    $name = test_input($_POST["name"]);
    $email = test_input($_POST["description"]);
    $passport = $_FILES["passport"];
    $passportTmp  = $passport['tmp_name'];
    $passportfilename = strtolower($passport["name"]);
    $passportfilesize = $passport["size"];
    $passportfilext = end(explode('.',$passportfilename));
    $passportDir = 'uploads/courseware/';
    $passportFullDir = '';
    
    //validate input
    if ($passportfilesize <= 0){
      $error = "Please Upload a Video of Not More Than 50mb!";
    }
    else if ($passportfilesize >= 100242880){
      $error = "File Cannot Be More Than 100mb!";
    }
    else if (empty($_POST["module"])){
      $error = "Please Enter Module!";
    }
    else if (empty($_POST["name"])){
      $error = "Please Enter Your Title!";
    }
    else if (empty($_POST["description"])){
      $error = "Description Is Required!";
    }
    else if (file_exists($passportfilename))
      {
         $msg = "<p class='label label-danger'>". $_FILES["file"]["name"] . " already exists. -
         Use another material. </p>";
      }
    else {
        $passportfilename = time().'.'.$passportfilext;

        $passportFullDir = $passportDir.$passportfilename;
        move_uploaded_file($passportTmp,$passportFullDir);
      $sql = "INSERT INTO videos (topic, title, module, class, description, media)
      VALUES ('$phone', '$name', '$module', 'JSS1', '$email', '$passportfilename')";
      if ($connect->query($sql) === TRUE){
        ?>
          <style>
            #tooltipm{
              display:block;
            }
          </style>
        <?php
        $name = $sname = $phone = $email = "";
      }
      else{
        echo "Error: " . $sql . "<br>" .$connect->error;
      }
      $connect->close();
    }
  }
  
  if (isset($error) && $error !== ""){
    ?>
      <style>
        #error{
          text-align:center;
          display:block;
          width:98.1%;
        }
      </style>
    <?php
  }
  else{
    ?>
      <style>
        #error{
          display:none;
        }
      </style>
    <?php
  }

?>

<?php require_once("includes/commonlinks.php"); ?>
  <body class="skin-blue">
    <div class="wrapper">
      
      <!--header-->
      <?php require_once("includes/header.php"); ?>
      <!--header-->

      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once("includes/aside.php"); ?>
      <!-- /.sidebar -->

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Videos for JSS1
            <small></small>
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
               
          <!-- //Tooltip -->

          <section class="content" id="view">
          
          <div class="box" style="font-size:12px;">
            <div class="box-header">
              <h3 class="box-title">Download Videos</h3>
              <?php
              if (isset($msg) && $msg !=='') {
                
              ?>
              <p class='pull-right'><?php echo $msg;?></p>
              <?php
              }
              ?>
            </div><!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="example1" class="table table-bordered table-striped" style="over-flow:scroll;">
                <thead>
                  <tr>
                    <th>S/N</th>
                    <th>MODULE</th>
                    <th>SUB-TOPIC</th>
                    <th>TITLE</th>
                    <th>DESCRIPTION</th>
                    <th>VIDEO</th>
                    <th>DATE UPLOADED</th>
                    <th>ACTION</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $query = mysqli_query($connect,"SELECT * FROM videos WHERE class ='JSS1' ORDER BY DateCreated DESC");
                    
                    if (mysqli_num_rows ($query)> 0) {
                      $counter = 0;
                      while ($rows = mysqli_fetch_array($query) ){
                        $serialnumber = ++$counter;
                        $ID = $rows['ID'];
                        $module = $rows['module'];
                        $email = $rows['topic'];
                        $name = $rows['title'];
                        $phone = $rows['description'];
                        $passport = $rows['media'];
                        $regdate = $rows['DateCreated'];
                        $action = '<a href="../uploads/courseware/'.$passport.'" download="'.$name.'" class="btn btn-primary"><i class="fa fa-download"></i> Download / <i class="fa fa-eye"></i> View</a>';


                        echo '<tr><td>'.$serialnumber.'</td><td>'.$module.'</td><td>'.$email.'</td><td>'.$name.'</td>
                        <td>'.$phone.'</td><td>'.$passport.'</td><td>'.$regdate.'</td><td>'.$action.'</td></tr>';
                      }
                    }
                  ?>
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </section><!-- /.content -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <?php require_once("includes/footer.php"); ?>

  </body>
</html>