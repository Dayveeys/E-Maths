<?php
  include_once "phpfiles/global.php";

  if (isset($_SESSION['student_bigdata'])) {
    unset($_SESSION['student_bigdata']);
    header("location:login.php");
    }

 ?>