<?php include_once 'phpfiles/global.php';


checkstudentnotlogged();

$title = "Student Profile";
?>

<?php
$error = $success = "";

if (isset($_GET['success'])) {
  $success = '<h4 id="delsucs" class="pull-right" style="color:white; padding:15px; width:300px; background-color:green; text-align:center; border-radius:5px;">Edited successfully!</h4>';
}

if (isset($_POST['update'])) {
   $student_firstname = checkinput($_POST['firstname']);
   $student_lastname = checkinput($_POST['lastname']);
   $student_othernames = checkinput($_POST['othernames']);
   $student_email = checkinput($_POST['email']);
   $student_password = checkinput($_POST['password']);
   $student_c_password = checkinput($_POST['c_password']);
   $student_gender = checkinput($_POST['gender']);
   $student_dob = checkinput($_POST['dob']);
   $student_phone = checkinput($_POST['phone']);
   $student_address = checkinput($_POST['address']);
   $student_state = checkinput($_POST['state']);
   $student_lga = checkinput($_POST['lga']);
   $student_nationality = checkinput($_POST['nationality']);

   if (!empty($student_firstname) || !empty($student_lastname) || !empty($student_email) || !empty($student_password) || !empty($student_dob) || !empty($student_phone) || !empty($student_address) || !empty($student_state) || !empty($student_lga) || !empty($student_nationality)) {
     if (!empty($student_firstname)) {
       if (!empty($student_lastname)) {
         if (!empty($student_email)) {
           if (!empty($student_password)) {
             if ($student_gender != 'choose') {
               if (!empty($student_dob)) {
                 if (!empty($student_phone)) {
                   if (!empty($student_address)) {
                     if (!empty($student_state)) {
                       if (!empty($student_lga)) {
                         if (!empty($student_nationality)) {
                           if ($student_programme != 'choose') {
                             if (preg_match("/^[a-zA-Z]*$/",$student_firstname)) {
                               if (preg_match("/^[a-zA-Z]*$/",$student_lastname)) {
                                 if (preg_match("/^[a-zA-Z ]*$/",$student_othernames)) {
                                   if (filter_var($student_email, FILTER_VALIDATE_EMAIL)) {
                                     if ($student_password == $student_c_password) {
                                       if (preg_match("/^[0-9\/]*$/",$student_dob)) {
                                         if (preg_match("/^(\d{2})\/(\d{2})\/(\d{4})$/", $student_dob)) {
                                           if (preg_match("/^[0-9]*$/",$student_phone)) {
                                             if (preg_match("/^[a-zA-Z0-9-+,. ]*$/",$student_address)) {
                                               if (preg_match("/^[a-zA-Z- ]*$/",$student_state)) {
                                                 if (preg_match("/^[a-zA-Z- ]*$/",$student_lga)) {
                                                   if (preg_match("/^[a-zA-Z- ]*$/",$student_nationality)) {
                                                     $sql = "update students set firstname = '$student_firstname', lastname = '$student_lastname', othernames = '$student_othernames', email = '$student_email', password = '$student_password', gender = '$student_gender', dob = '$student_dob', phone = '$student_phone', address = '$student_address', state = '$student_state', lga = '$student_lga', nationality = '$student_nationality'";
                                                     $query = mysqli_query($connect, $sql);
                                                     if ($query) {
                                                       header('location: profile.php?success');
                                                     }else {
                                                       $error = "An error occured, please try again.";
                                                     }
                                                   }else {
                                                     $error = "Please, type a valid country name.";
                                                   }
                                                 }else {
                                                   $error = "Please, type a valid LGA name.";
                                                 }
                                               }else {
                                                 $error = "Please, type a valid state name.";
                                               }
                                             }else {
                                               $error = "Please, type a valid address.";
                                             }
                                           }else {
                                             $error = "Please, type a valid phone number.";
                                           }
                                         }else {
                                             $error = "Please, use DD/MM/YYYY for date of birth.";
                                           }
                                       }else {
                                         $error = "Please, use DD/MM/YYYY for date of birth.";
                                       }
                                     }else {
                                       $error = "Password does not match!";
                                     }
                                   }else {
                                     $error = "Please type correct email address";
                                   }
                                 }else {
                                   $error = "Please, type your valid othernames.";
                                 }
                               }else {
                                 $error = "Please, type your a valid lastname.";
                               }
                             }else {
                               $error = "Please, type your a valid firstname.";
                             }
                           }else {
                             $error = "Please, choose your programme.";
                           }
                         }else {
                           $error = "Please, type your country name.";
                         }
                       }else {
                         $error = "Please, type your local government area.";
                       }
                     }else {
                       $error = "Please, type your state.";
                     }
                   }else {
                     $error = "Please, type your address.";
                   }
                 }else {
                   $error = "Please, type your phone number.";
                 }
               }else {
                 $error = "Please, type your date of birth.";
               }
             }else {
               $error = "Please, choose your gender.";
             }
           }else {
             $error = "Please, type your password.";
           }
         }else {
           $error = "Please, type your email address.";
         }
       }else {
         $error = "Please, type your lastname.";
       }
     }else {
       $error = "Please, type your firstname.";
     }
   }else {
     $error = "All fields marked * is required";
   }
 }

 if (isset($_POST['update_photo'])) {
   if (isset($_FILES['passport']['tmp_name'])) {
     $name = $_FILES['passport']['name'];
     $size = $_FILES['passport']['size'];
     $type = $_FILES['passport']['type'];
     if (getimagesize($_FILES['passport']['tmp_name']) == true) {
       if ($type == "image/jpeg" || $type == "image/png") {
         $name = strtolower($student_firstname."-".$student_phone.".png");
         if (move_uploaded_file($_FILES['passport']['tmp_name'], "uploads/passport/".$name)) {
           $sql = "update students set passport = '$name' where id = '$student_id' limit 1";
           $query = mysqli_query($connect, $sql);
           if ($query) {
             header('location: profile.php?success');
           }else {
             $error = "An error occured, please try again.";
           }
         }else {
           $error = "An error occured, please try again!!";
         }
       }else {
         $error = "Unsupported file format!";
       }
     }else {
       $error = "Please, select an image file!";
     }
   }
 }
?>

<?php require_once("includes/commonlinks.php"); ?>
  <body class="skin-blue">
    <div class="wrapper">
      
      <!--header-->
      <?php require_once("includes/header.php"); ?>
      <!--header-->

      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once("includes/aside.php"); ?>
      <!-- /.sidebar -->

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php echo $title; ?>
          </h1>
          <div class="col-sm-6">
            <span style="background-color: red;color: #fff;" class="pull-right"><?php echo $error; ?></span>
          </div>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row col-lg-12">
              <button style="margin-top: -0.5%;" class="btn btn-success left-block" id="shobtn">Edit Profile</button>
          </div><br><!-- /.row -->          
                  
                  <div style="margin-top: 3%;" id="usereg" class="center-block panel panel-primary" style="width:60%;">
                    <div class="panel-heading">
                      <h3 class="title align-center">Profile Edit Panel<button style="float: right; margin-top: -0.5%;" class="btn btn-default right-block" id="dhbtn">Close</button></h3>
                    </div>
                    <div class="panel-body">
                     
                      <form action="profile.php" method="post" enctype="multipart/form-data">
                        <div class="col-sm-6">
                          <div class="w3-card w3-margin-bottom" style="width:140px; height:140px; padding: 5px; display:inline-block">
                            <img src="uploads/passport/<?php echo $student_passport; ?>" alt="Upload Passport" style="width:100%;" />
                          <input class="form-control btn btn-primary btn-file center-block" style="overflow:hidden;white-space:normal;text-overflow:clip;margin-top: 10%;width:400px;" type="file" name="passport" required>
                          <input class="btn btn-success form-control w3-hover-text-white" style="overflow:hidden;white-space:normal;text-overflow:clip;margin-top: 10%;width:400px;" type="submit" name="update_photo" value="Update">
                          </div>
                        </div>
                        
                        <div class="clear"></div>
                      </form>

                      <form action="profile.php" method="post">
                        <div class="col-sm-6">
                          <label>Firstname:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" value="<?php echo $student_firstname; ?>" name="firstname" placeholder="Enter your firstname..">

                          <label>Lastname:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" value="<?php echo $student_lastname; ?>" name="lastname" placeholder="Enter your lastname..">

                          <label>Othernames:</label>
                          <input class="form-control w3-margin-bottom" type="text" value="<?php echo $student_othernames; ?>" name="othernames" placeholder="Enter your othernames..">

                          <label>Email:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" value="<?php echo $student_email; ?>" name="email" placeholder="Enter your email..">

                          <label>Password:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="password" value="<?php echo $student_password; ?>" name="password" placeholder="Enter your password..">

                          <label>Re-type Password:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="password" value="" name="c_password" placeholder="Re-type your password..">

                          <label>Gender:</label><span class="w3-text-red">*</span>
                          <select class="form-control w3-margin-bottom" name="gender">
                            <option value="choose">-- Choose --</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                          </select>
                        </div>

                        <div class="col-sm-6">
                          <label>Date of birth:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="dob" value="<?php echo $student_dob; ?>" placeholder="DD/MM/YYYY">

                          <label>Phone number:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="phone" value="<?php echo $student_phone; ?>" placeholder="Enter your phone number">

                          <label>Address:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="address" value="<?php echo $student_address; ?>" placeholder="Enter your address">

                          <label>State:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="state" value="<?php echo $student_state; ?>" placeholder="Enter your state">

                          <label>LGA:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="lga" value="<?php echo $student_lga; ?>" placeholder="Enter your LGA">

                          <label>Nationality:</label><span class="w3-text-red">*</span>
                          <input class="form-control w3-margin-bottom" type="text" name="nationality" value="<?php echo $student_nationality; ?>" placeholder="Enter your nationality">

                        </div>

                        <div class="col-sm-12">
                          <br>
                          <input class="btn btn-success form-control w3-hover-text-white" type="submit" name="update" value="Update">
                          <br><br>
                        </div>
                      </form>
                    </div>
                  </div><br>
               
          <!-- //Tooltip -->

          <section class="" id="view">
          
          <div class="box col-lg-12" style="font-size:12px;">
            <div class="box-header">
              <h3 class="box-title">My Profile</h3>
              <?php
              if (isset($success) && $success !=='') {
                
              ?>
              <p class='pull-right'><?php echo $success;?></p>
              <?php
              }
              ?>
            </div><!-- /.box-header -->
            <div class="box-body responsive">
              <div class="col-sm-6">
                <div class="" style="width:140px; height:140px; padding: 5px; display:inline-block">
                  <img src="uploads/passport/<?php echo $student_passport; ?>" alt="Upload Passport" style="width:100%;" />
                </div>
              </div>
              <div class="col-sm-6 w3-margin-bottom w3-right-align">

              </div>
              <div class="clear"></div>
              <div class="col-lg-6">
                <p style="font-size:15px;"><b>Lastname:</b> <?php echo $student_lastname; ?></p>
                <p style="font-size:15px;"><b>Firstname:</b> <?php echo $student_firstname; ?></p>
                <p style="font-size:15px;"><b>Othernames:</b> <?php echo $student_othernames; ?></p>
                <p style="font-size:15px;"><b>Date of birth:</b> <?php echo $student_dob; ?></p>
                <p style="font-size:15px;"><b>Gender:</b> <?php echo $student_gender; ?></p>
              </div>
              <div class="col-lg-6">
                <p style="font-size:15px;"><b>LGA:</b> <?php echo $student_lga; ?></p>
                <p style="font-size:15px;"><b>Phone number:</b> <?php echo $student_phone; ?></p>
                <p style="font-size:15px;"><b>Email:</b> <?php echo $student_email; ?></p>
                <p style="font-size:15px;"><b>Reg number:</b> <?php echo $student_reg_no; ?></p>
                <p style="font-size:15px;"><b>Class:</b> <?php echo $student_programme; ?></p>
              </div><!-- /.box-body -->
              <div class="col-md-12"><hr></div>
          </div><!-- /.box -->

        </section><!-- /.content -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <?php require_once("includes/footer.php"); ?>

  </body>
</html>