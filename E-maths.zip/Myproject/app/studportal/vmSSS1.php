<?php require_once("includes/dbkey.php"); ?>
<?php
include_once 'phpfiles/global.php';

// if (isset($_GET['res']) && $_GET['res'] !== '' && $_GET['res'] == 'yes') {

//     $msg ='<h4 id="delsucs" class="pull-right" style="color:white; padding:15px; width:300px; background-color:green; text-align:center; border-radius:5px;">Deleted successfully!</h4>';
//   }


?>



<?php
 $passport='';

  if (isset($_GET['ID']) && $_GET['ID'] !== '') {
    $ID = $_GET['ID'];
  }
?>

<?php require_once("includes/commonlinks.php"); ?>
  <body class="skin-blue">
    <div class="wrapper">
      
      <!--header-->
      <?php require_once("includes/header.php"); ?>
      <!--header-->

      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once("includes/aside.php"); ?>
      <!-- /.sidebar -->

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->

        <!-- Main content -->
        <section class="content-header">
          <h1>
            All Modules for SSS1
          </h1>
          <div class="col-sm-6">
            <span class="w3-right"><?php echo $notify; ?></span>
          </div>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              

                  <?php
                    $query = mysqli_query($connect,"SELECT DISTINCT module, ID FROM videos WHERE class ='SSS1' GROUP BY module DESC");
                    
                    if (mysqli_num_rows ($query)> 0) {
                      while ($rows = mysqli_fetch_array($query) ){
                        $ID = $rows['ID'];
                        $module = $rows['module'];
                        $action ='<a href="vmoudleview.php?ID='. $ID .'" class="small-box-footer">Watch & Download Videos</a>';

                        echo '<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green-gradient">
                <div class="inner">
                  <h4><i style="font-size:25px;" class="fa fa-caret-square-o-right"></i> '.$module.'</h4>
                </div>
                '.$action.'
              </div>
            </div><!-- ./col -->';
                      }
                    }
                    else{
                          echo '<div class="col-lg-12 col-xs-12">
              <!-- small box -->
              <div class="small-box bg-green-gradient">
                <div class="inner">
                  <h3>Sorry <i class="fa fa-meh-o"></i></h3>
                  <h1>No contents yet, please check back later</h1>
                </div>
              </div>
            </div><!-- ./col -->';
                    }
                  ?>
                
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </section><!-- /.content -->
        
      </div><!-- /.content-wrapper -->

      <?php require_once("includes/footer.php"); ?>

  </body>
</html>