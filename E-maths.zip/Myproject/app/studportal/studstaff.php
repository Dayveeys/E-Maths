<?php
include_once 'phpfiles/global.php';
include_once 'includes/dbkey.php';

checkstudentnotlogged();
$title = "My Tutors";

?>


<?php require_once("includes/commonlinks.php"); ?>
  <body class="skin-blue">
      
      <!--header-->
      <?php require_once("includes/header.php"); ?>
      <!--header-->

      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once("includes/aside.php"); ?>
      <!-- /.sidebar -->

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php echo $title; ?>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
                   
               
          <!-- //Tooltip -->

          <section class="">
          
          <div class="box col-lg-12" style="font-size:12px;">
            <div class="box-header">
              <h3 class="box-title">Tutors Details</h3>
            </div><!-- /.box-header -->
            <div class="box-body responsive">
            <table id="example1" class="table table-bordered table-striped" style="over-flow:scroll;">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Fullname</th>
                <th>Username</th>
                <th>Email</th>
                <th>Class</th>
                <th>Phone number</th>
              </tr>
            </thead>

            <tbody>
              <?php
                $sql = "select * from reg_admin where level = 'staff'  ORDER BY date_reg DESC";
                $result = mysqli_query($connect, $sql);
                if ($result) {
                  $sn = 0;
                  while ($found = mysqli_fetch_array($result)) {
                    $sn++;
                    $id = $found['id'];
                    $fullname = $found['fullname'];
                    $username = $found['username'];
                    $email = $found['email'];
                    $phone = $found['phone'];
                    $programme = $found['programme'];
                    ;

                      echo "
                        <tr>
                          <td>{$sn}</td>
                          <td>{$fullname}</td>
                          <td>{$username}</td>
                          <td>{$email}</td>
                          
                          <td>{$programme}</td>
                          <td>{$phone}</td>
                          
                          
                        </tr>
                      ";
                  }
                }
              ?>
            </tbody>
            </table>
          </div><!-- /.box -->
        </section><!-- /.content -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <?php require_once("includes/footer.php"); ?>

  </body>
</html>