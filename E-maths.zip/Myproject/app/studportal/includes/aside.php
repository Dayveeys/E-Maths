<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- search form -->
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search..."/>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            
            <li class="active treeview">
              <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
                       
            <li><a href="profile.php"><i class="fa fa-user"></i> My Profile</a></li>
              
            <li class="treeview">
              <a href="#">
                <i class="fa fa-book"></i> <span>Course Modules (Text)</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="mJSS1.php"><i class="fa fa-files-o"></i> JSS1</a></li>
                <li><a href="mJSS2.php"><i class="fa fa-files-o"></i> JSS2</a></li>
                <li><a href="mJSS3.php"><i class="fa fa-files-o"></i> JSS3</a></li>
                <li><a href="mSSS1.php"><i class="fa fa-files-o"></i> SSS1</a></li>
                <li><a href="mSSS2.php"><i class="fa fa-files-o"></i> SSS2</a></li>
                <li><a href="mSSS3.php"><i class="fa fa-files-o"></i> SSS3</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-video-camera"></i> <span>Course Modules (Video)</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="vmJSS1.php"><i class="fa fa-caret-square-o-right"></i> JSS1</a></li>
                <li><a href="vmJSS2.php"><i class="fa fa-caret-square-o-right"></i> JSS2</a></li>
                <li><a href="vmJSS3.php"><i class="fa fa-caret-square-o-right"></i> JSS3</a></li>
                <li><a href="vmSSS1.php"><i class="fa fa-caret-square-o-right"></i> SSS1</a></li>
                <li><a href="vmSSS2.php"><i class="fa fa-caret-square-o-right"></i> SSS2</a></li>
                <li><a href="vmSSS3.php"><i class="fa fa-caret-square-o-right"></i> SSS3</a></li>
              </ul>
            </li>

            <li>
              <a href="../quiz/index2.php">
                <i class="fa fa-question-circle"></i> <span>Quiz and Skill Test</span>
              </a>
            </li>
            <li><a href="studstaff.php"><i class="fa fa-users"></i>My Tutors</a></li>
            <li>
              <a href="logout.php">
                <i class="glyphicon glyphicon-log-out"></i> <span>Logout</span>
              </a>
            </li>
          </ul>
        </section>
</aside>
