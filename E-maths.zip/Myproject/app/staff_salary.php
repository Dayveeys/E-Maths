<?php
include_once 'phpfiles/global.php';

checknotlogged();

$title = "Staff Salary";
$active8 = "bg-white";

if (isset($_GET['success'])) {
  $notify = "<span class=\"alert-success w3-padding\">Update successful</span>";
}

if (isset($_POST['update'])) {
  $id = checkinput($_POST['id']);
  $salary = checkinput($_POST['salary']);

  if (preg_match("/^[0-9]*$/",$salary)) {
    $sql = "update reg_admin set salary = '$salary' where id = '$id' limit 1";
    if (mysqli_query($connect, $sql)) {
      header('location: staff_salary.php?success');
    }
  }else {
    $notify = "<span class=\"alert-danger w3-padding\">Please check and type correct salary amount!</span>";
  }
}

include_once 'header.php' ?>

<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>

  <div class="table-responsive">
    <table class="table table-striped table-hover">
      <tr>
        <th>S/N</th>
        <th>Fullname</th>
        <th>Qualification</th>
        <th>Salary</th>
        <th>Duration</th>
        <th></th>
        <th></th>
      </tr>

      <?php
        $sql = "select * from reg_admin where level = 'staff'";
        $result = mysqli_query($connect, $sql);
        if ($result) {
          $sn = 0;
          $salary_sum = 0;
          while ($found = mysqli_fetch_array($result)) {
            $sn++;
            $id = $found['id'];
            $fullname = $found['fullname'];
            $username = $found['username'];
            $password = $found['password'];
            $email = $found['email'];
            $gender = $found['gender'];
            $phone = $found['phone'];
            $address = $found['address'];
            $qualification = $found['qualification'];
            $programme = $found['programme'];
            $salary = $found['salary'];
            $salary_sum += $salary;
            if ($salary == "") {
              $salary = "-";
            }else {
              $salary = "N$salary";
            }

              echo "
                <tr>
                  <td>{$sn}</td>
                  <td>{$fullname}</td>
                  <td>{$qualification}</td>
                  <td>{$salary}</td>
                  <td>Monthly</td>
                  <form action=\"staff_salary.php\" method=\"post\">
                    <td styles=\"min-width: 10px;\"><input type=\"text\" class=\"form-control\" name=\"salary\" value=\"\"></td>
                    <td>
                      <input type=\"hidden\" class=\"\" name=\"id\" value=\"$id\">
                      <input type=\"submit\" class=\"btn btn-success\" name=\"update\" value=\"Update\">
                    </td>
                  </form>
                </tr>
              ";
          }
          echo "
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th>Total = N$salary_sum</th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          ";
        }
      ?>

    </table>
  </div>

</div>

<?php include_once 'footer.php' ?>
