# Online-Exam-System-
Online examination system is a app for setup online quiz with so many functionality.
It is a PHP project.


Instalation ::

step 1)Copy full folder in your web directory.

2)Import database in your phpmyadmin named project.sql.

3)Edit dbconnection file.change username,password and database name.Default user is root,password is null and database name is project.

Default admin emailid is sunnygkp10@gmail.com and password is 123456 .
admin password is md5 encypted.

For any query or feedback contact me at sunnygkp10@gmail.com.

Thanx.

