<?php
include_once 'phpfiles/global.php';

checknotlogged();

if ($admin_level != 'super') {
  header("location: index.php");
}

$title = "Register Admin/Staff";
$active2 = "bg-white";
$fullname = $username = $security_key = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $fullname = checkinput($_POST['fullname']);
  $username = checkinput($_POST['username']);
  $security_key = checkinput($_POST['security_key']);
  $level = checkinput($_POST['level']);
  $password = checkinput($_POST['password']);

  if (!empty($fullname) || !empty($username) || !empty($security_key) || !empty($password)) {
    if (!empty($fullname)) {
      if (!empty($username)) {
        if (!empty($security_key)) {
          if (!empty($password)) {
            if (preg_match("/^[a-zA-Z. ]*$/",$fullname)) {
              if (preg_match("/^[a-z0-9 ]*$/",$username)) {
                if (preg_match("/^[a-zA-Z0-9 ]*$/",$security_key)) {
                  if ($level != 'choose') {
                    if (strlen($password) >= 5) {
                      $sql = "select id from reg_admin where username = '$username'";
                      $check = mysqli_query($connect, $sql);
                      if ($check) {
                        if (!mysqli_num_rows($check) > 0) {
                          $password = sha1($password);
                          $date_reg = date("d/m/Y");
                          $time_reg = date("h:ia");
                          $sql = "insert into reg_admin (fullname, username, level, security_key, password, status, block, date_reg, time_reg)
                          values('$fullname', '$username', '$level', '$security_key', '$password', 'No', 'No', '$date_reg', '$time_reg')";
                          if (mysqli_query($connect, $sql)) {
                            $notify = "<span class=\"alert-success w3-padding\">Admin has been registerd successfully!</span>";
                            $fullname = $username = $security_key = $password = "";
                          }
                        }else {
                          $notify = "<span class=\"alert-danger w3-padding\">Username already exists!</span>";
                        }
                      }else {
                        $notify = "<span class=\"alert-danger w3-padding\">An error occured!</span>";
                      }
                    }else {
                      $notify = "<span class=\"alert-danger w3-padding\">Password must be 5 and above!</span>";
                    }
                  }else {
                    $notify = "<span class=\"alert-danger w3-padding\">Please choose level!</span>";
                  }
                }else {
                  $notify = "<span class=\"alert-danger w3-padding\">Choose only alphabets and/or numbers for your security key!</span>";
                }
              }else {
                $notify = "<span class=\"alert-danger w3-padding\">Choose only lowercase letters and/or numbers for your username!</span>";
              }
            }else {
              $notify = "<span class=\"alert-danger w3-padding\">Enter valid full name!</span>";
            }
          }else {
            $notify = "<span class=\"alert-danger w3-padding\">Password field is required!</span>";
          }
        }else {
          $notify = "<span class=\"alert-danger w3-padding\">Security key field is required!</span>";
        }
      }else {
        $notify = "<span class=\"alert-danger w3-padding\">Username field is required!</span>";
      }
    }else {
      $notify = "<span class=\"alert-danger w3-padding\">Full name field is required!</span>";
    }
  }else {
    $notify = "<span class=\"alert-danger w3-padding\">All fields are required!</span>";
  }
}

include_once 'header.php' ?>

<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>
  <form action="reg_admin.php" method="post">
    <div class="col-sm-4">
      <div class="form-group">
        <label for="fullname">Full Name</label>
        <input class="form-control" type="text" name="fullname" placeholder="Enter Fullname" value="<?php echo $fullname; ?>">
      </div>
      <div class="form-group">
        <label for="username">Username</label>
        <input class="form-control" type="text" name="username" placeholder="Enter Username" value="<?php echo $username; ?>">
      </div>
    </div>
    <div class="col-sm-4">
      <div class="form-group">
        <label for="security_key">Security Key</label>
        <input class="form-control" type="text" name="security_key" placeholder="Enter Security Key" value="<?php echo $security_key; ?>">
      </div>
      <div class="form-group">
        <label for="level">Level</label>
        <select class="form-control" name="level">
          <option value="choose">-- Choose --</option>
          <option value="super">Admin</option>
          <option value="staff">Staff</option>
        </select>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="form-group">
        <label for="password">Password</label>
        <input class="form-control" type="password" name="password" placeholder="Enter Password" value="<?php echo $password; ?>">
      </div>
    </div>
    <div class="col-sm-12">
    <br>
      <div class="form-group">
        <input class="btn bg-color2 w3-text-white" type="submit" name="submit" value="Register">
      </div>
    </div>
  </form>
</div>

<?php include_once 'footer.php' ?>
