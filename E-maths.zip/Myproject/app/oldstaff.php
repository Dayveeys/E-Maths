<?php
include_once 'phpfiles/global.php';

checknotlogged();

if ($admin_level != 'super') {
  header("location: index.php");
}

$title = "Staff Details";
$active3 = "bg-white";


include_once 'header.php' ?>

<div class="w3-container">
  <br>
  <div class="row">
    <div class="col-sm-6">
      <h3><?php echo $title; ?></h3>
    </div>
    <div class="col-sm-6">
      <span class="w3-right"><?php echo $notify; ?></span>
    </div>
  </div>
  <hr>

  <div class="table-responsive">
    <table class="table table-striped table-hover">
      <tr>
        <th>S/N</th>
        <th>Fullname</th>
        <th>Username</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Programme</th>
        <th>Phone number</th>
        <th>Address</th>
        <th>Qualification</th>
      </tr>

      <?php
        $sql = "select * from reg_admin where level = 'staff'";
        $result = mysqli_query($connect, $sql);
        if ($result) {
          $sn = 0;
          while ($found = mysqli_fetch_array($result)) {
            $sn++;
            $id = $found['id'];
            $fullname = $found['fullname'];
            $username = $found['username'];
            $password = $found['password'];
            $email = $found['email'];
            $gender = $found['gender'];
            $phone = $found['phone'];
            $address = $found['address'];
            $qualification = $found['qualification'];
            $programme = $found['programme'];

              echo "
                <tr>
                  <td>{$sn}</td>
                  <td>{$fullname}</td>
                  <td>{$username}</td>
                  <td>{$email}</td>
                  <td>{$gender}</td>
                  <td>{$programme}</td>
                  <td>{$phone}</td>
                  <td>{$address}</td>
                  <td>{$qualification}</td>
                </tr>
              ";
          }
        }
      ?>
    </table>
  </div>

</div>

<?php include_once 'footer.php' ?>
