<?php
include_once 'app/quiz/dbConnection.php';

    $success="";

if (isset($_POST['submit'])) {
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$id=uniqid();
$date=date("Y-m-d");
$time=date("h:i:sa");
$feedback = $_POST['feedback'];
$q=mysqli_query($con,"INSERT INTO feedback VALUES  ('$id' , '$name', '$email' , '$subject', '$feedback' , '$date' , '$time')")or die ("Error");
    $success="Feedback sent successfully!";
}else{
  $error="Feedback not sent!";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>E-Maths | Students Registeration</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="shortcut icon" href="images/favicon.png">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Vegur_700.font.js"></script>
<script type="text/javascript" src="js/Vegur_400.font.js"></script>
<script type="text/javascript" src="js/Vegur_300.font.js"></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.box1 figure{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
<body id="page5">
<div class="body1">
  <div class="main">
        <?php include_once ('header.php'); ?>
    <!-- content -->
    <article id="content">
      <div class="wrapper">
        <div class="box1">
          <div class="line1 wrapper">
            <h2>Please give us your feedback using the Contact Form below</h2>
          </div>
        </div>
      </div>
      <div class="wrapper">
        <div class="whole w3-margin-top">
        <div class="w3-center" style="color: #fff;">
          <h2>Contact Form</h2><span class="btn btn-danger" id="usereg"><?php echo $error; ?></span><span class="btn btn-success" id="delsucs"><?php echo $success; ?></span>
        </div>
        <hr>
        <div class="relative">
          <img src="images/page6_img1.png" alt="" class="img1">
          <form action="contact.php" method="post" enctype="multipart/form-data" style="color: yellow;">

          <div class="col-sm-6">
            <label>Name:</label><span class="w3-text-red">*</span>
            <input required id="name" name="name" placeholder="Enter your name" class="form-control input-md" type="text">

            <label>Subject:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" id="name" name="subject" placeholder="Enter subject" class="form-control input-md" type="text">

            <label>Email:</label>
            <input required class="form-control w3-margin-bottom" id="email" name="email" placeholder="Enter your email" class="form-control input-md" type="email">
          </div>

          <div class="col-sm-6">
            <label>Comment:</label><span class="w3-text-red">*</span>
            <textarea required rows="5" cols="8" name="feedback" class="form-control" placeholder="Write feedback here..."></textarea>
            <br>

            <input required class="btn btn-success form-control w3-hover-text-white" type="submit" name="submit" value="Send">
          </div>
        </form>
        </div>
      </div>
    </div>
  </article><hr>
    <!-- / content -->
    <!-- footer -->
    <footer>
      <div class="wrapper"> <a href="index.html" id="footer_logo"><span>E-</span>Maths</a>
      </div>
      <div class="wrapper">
        <nav>
          <ul id="footer_menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="app/studportal/login.php">Login</a></li>
            <li><a href="reg.php">Sign Up</a></li>
            <li><a href="help.php"></a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </nav>
        <div class="tel"><span>+234 70</span>6 896 9591</div>
      </div>
      <div id="footer_text" style="color: #fff;">Copyright &copy; <script>var y = new Date(); document.write(y.getFullYear()+" ");
      </script> 
        E-maths</strong> All rights reserved | Design by Umeoka Davis</div>
    </footer>
    <!-- / footer -->
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
 <script>
        $("#delsucs2").hide();
        $("#viewbtn").hide();
        $("#usereg").hide();
        $("#shobtn").on("click", function(){
          $("#usereg").show("slow");
        });
        $("#dhbtn").on("click", function(){
          $("#usereg").hide("slow");
        });
      </script>

      <?php
        if (isset($success)){
          ?>
          <script>
            setTimeout(function(){
                if ($('#delsucs').length > 0) {
                  $('#delsucs').fadeOut("slow");
                }
              }, 5000)   
          </script>
          <?php
        }
      ?>
      <?php
        if (isset($error)){
          ?>
          <script>
                  $('#usereg').show();   
          </script>
          <?php
        }
      ?>
</body>
</html>