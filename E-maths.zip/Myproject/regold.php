<?php
include_once 'phpfiles/global.php';
include_once 'app/includes/dbkey2.php';

checkstudentlogged();

$title = "Student Portal Signup";

$success = $error = $passport = $firstname = $lastname = $othernames = $email = $password = $c_password = $gender = $dob = $phone = $address = $state = $lga = $nationality = $programme = $school = "";



if (isset($_POST['signup'])) {
   $firstname = checkinput($_POST['firstname']);
   $lastname = checkinput($_POST['lastname']);
   $othernames = checkinput($_POST['othernames']);
   $email = checkinput($_POST['email']);
   $password = checkinput($_POST['password']);
   $c_password = checkinput($_POST['c_password']);
   $gender = checkinput($_POST['gender']);
   $dob = checkinput($_POST['dob']);
   $phone = checkinput($_POST['phone']);
   $address = checkinput($_POST['address']);
   $state = checkinput($_POST['state']);
   $lga = checkinput($_POST['lga']);
   $nationality = checkinput($_POST['nationality']);
   $programme = checkinput($_POST['programme']);
   $school = checkinput($_POST['school']);


   if (!empty($firstname) || !empty($lastname) || !empty($email) || !empty($password) || !empty($dob) || !empty($phone) || !empty($address) || !empty($state) || !empty($lga) || !empty($nationality)) {
     if (!empty($firstname)) {
       if (!empty($lastname)) {
         if (!empty($email)) {
           if (!empty($password)) {
             if ($gender != 'choose') {
               if (!empty($dob)) {
                 if (!empty($phone)) {
                   if (!empty($address)) {
                     if (!empty($state)) {
                       if (!empty($lga)) {
                         if (!empty($nationality)) {
                           if ($programme != 'choose') {
                             if (preg_match("/^[a-zA-Z]*$/",$firstname)) {
                               if (preg_match("/^[a-zA-Z]*$/",$lastname)) {
                                 if (preg_match("/^[a-zA-Z ]*$/",$othernames)) {
                                   if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                     if ($password == $c_password) {
                                       if (preg_match("/^[0-9\/]*$/",$dob)) {
                                         if (preg_match("/^(\d{2})\/(\d{2})\/(\d{4})$/", $dob)) {
                                           if (preg_match("/^[0-9]*$/",$phone)) {
                                             if (preg_match("/^[a-zA-Z0-9-+,. ]*$/",$address)) {
                                               if (preg_match("/^[a-zA-Z- ]*$/",$state)) {
                                                 if (preg_match("/^[a-zA-Z- ]*$/",$lga)) {
                                                   if (preg_match("/^[a-zA-Z- ]*$/",$nationality)) {
                                                     $sql = "select * from students where email = '$email'";
                                                     $result = mysqli_query($connect, $sql);
                                                     if (!mysqli_num_rows($result) > 0) {
                                                        $password = md5($password);
                                                       if (isset($_FILES['passport']['tmp_name'])) {
                                                         $name = $_FILES['passport']['name'];
                                                         $size = $_FILES['passport']['size'];
                                                         $type = $_FILES['passport']['type'];
                                                         if (getimagesize($_FILES['passport']['tmp_name']) == true) {
                                                           if ($type == "image/jpeg" || $type == "image/png") {
                                                             $name = strtolower($firstname."-".$phone.".png");
                                                             if (move_uploaded_file($_FILES['passport']['tmp_name'], "app/studportal/uploads/passport/".$name)) {
                                                               $reg_no = "EMTH/".date('Y')."/".rand(0001,9999).rand(01,99);
                                                               $date_reg = date("d/m/Y");
                                                               $time_reg = date("h:ia");
                                                               $sql = "insert into students (passport, reg_no, firstname, lastname, othernames, email, password, gender, dob, phone, address, state, lga, nationality, programme, school, date_reg, time_reg)
                                                               values('$name', '$reg_no', '$firstname', '$lastname', '$othernames', '$email', '$password', '$gender', '$dob', '$phone', '$address', '$state', '$lga', '$nationality', '$programme', '$school', '$date_reg', '$time_reg')";
                                                               $query = mysqli_query($connect, $sql);
                                                               
                                                                $sql2 = "insert into user (name, gender, college, email, mob, password)
                                                                 values('$firstname $lastname', '$gender', '$school', '$email', '$phone', '$password')";

                                                               
                                                               $query2 = mysqli_query($connect2, $sql2);

                                                               if ($query) {
                                                                 $success = "Registeration was successful! Kindly login to view your profile.";
                                                                }if ($query2) {
                                                                 $success = "Registeration was successful! Kindly login to view your profile2.";
                                                               }else {
                                                                 $error = "An error occured, please try again.";
                                                               }
                                                             }else {
                                                               $error = "An error occured, please try again!!";
                                                             }
                                                           }else {
                                                             $error = "Unsupported file format!";
                                                           }
                                                         }else {
                                                           $error = "Please, select an image file!";
                                                         }
                                                       }
                                                     }else {
                                                       $error = "Email address already registered.";
                                                     }
                                                   }else {
                                                     $error = "Please, type a valid country name.";
                                                   }
                                                 }else {
                                                   $error = "Please, type a valid LGA name.";
                                                 }
                                               }else {
                                                 $error = "Please, type a valid state name.";
                                               }
                                             }else {
                                               $error = "Please, type a valid address.";
                                             }
                                           }else {
                                             $error = "Please, type a valid phone number.";
                                           }
                                         }else {
                                             $error = "Please, use DD/MM/YYYY for date of birth.";
                                           }
                                       }else {
                                         $error = "Please, use DD/MM/YYYY for date of birth.";
                                       }
                                     }else {
                                       $error = "Password does not match!";
                                     }
                                   }else {
                                     $error = "Please type correct email address";
                                   }
                                 }else {
                                   $error = "Please, type your valid othernames.";
                                 }
                               }else {
                                 $error = "Please, type your a valid lastname.";
                               }
                             }else {
                               $error = "Please, type your a valid firstname.";
                             }
                           }else {
                             $error = "Please, choose your programme.";
                           }
                         }else {
                           $error = "Please, type your country name.";
                         }
                       }else {
                         $error = "Please, type your local government area.";
                       }
                     }else {
                       $error = "Please, type your state.";
                     }
                   }else {
                     $error = "Please, type your address.";
                   }
                 }else {
                   $error = "Please, type your phone number.";
                 }
               }else {
                 $error = "Please, type your date of birth.";
               }
             }else {
               $error = "Please, choose your gender.";
             }
           }else {
             $error = "Please, type your password.";
           }
         }else {
           $error = "Please, type your email address.";
         }
       }else {
         $error = "Please, type your lastname.";
       }
     }else {
       $error = "Please, type your firstname.";
     }
   }else {
     $error = "All fields marked * is required";
   }
 }

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>E-Maths | Students Registeration</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="shortcut icon" href="images/favicon.png">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Vegur_700.font.js"></script>
<script type="text/javascript" src="js/Vegur_400.font.js"></script>
<script type="text/javascript" src="js/Vegur_300.font.js"></script>
<script type="text/javascript" src="js/atooltip.jquery.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">.box1 figure{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
<body id="page5">
<div class="body1">
  <div class="main">
        <?php include_once ('header.php'); ?>
    <!-- content -->
    <article id="content">
      <div class="wrapper">
        <div class="whole w3-margin-top">
        <div class="w3-center" style="color: #fff;">
          <h2>Students Registration</h2>
        </div>
        <hr>
        <div class="relative">
          <span class="btn btn-danger" id="usereg"><?php echo $error; ?></span><span class="btn btn-success" id="delsucs"><?php echo $success; ?></span>
          <img src="images/page6_img1.png" alt="" class="img1">
          
          <form action="reg.php" method="post" enctype="multipart/form-data" style="color: yellow;">
          <div class="col-sm-6">
            <label>Passport:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="file" name="passport" required>

            <label>Firstname:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" value="<?php echo $firstname; ?>" name="firstname" placeholder="Enter your firstname..">

            <label>Lastname:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" value="<?php echo $lastname; ?>" name="lastname" placeholder="Enter your lastname..">

            <label>Othernames:</label>
            <input required class="form-control w3-margin-bottom" type="text" value="<?php echo $othernames; ?>" name="othernames" placeholder="Enter your othernames..">

            <label>Email:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" value="<?php echo $email; ?>" name="email" placeholder="Enter your email..">

            <label>Password:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="password" value="<?php echo $password; ?>" name="password" placeholder="Enter your password..">

            <label>Re-type Password:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="password" value="<?php echo $c_password; ?>" name="c_password" placeholder="Re-type your password..">

            <label>Gender:</label><span class="w3-text-red">*</span>
            <select class="form-control w3-margin-bottom" name="gender">
              <option value="choose">-- Choose --</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>

          <div class="col-sm-6">
            <label>Date of birth:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="dob" value="<?php echo $dob; ?>" placeholder="DD/MM/YYYY">

            <label>Phone number:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="phone" value="<?php echo $phone; ?>" placeholder="Enter your phone number">

            <label>Address:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="address" value="<?php echo $address; ?>" placeholder="Enter your address">

            <label>State:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="state" value="<?php echo $state; ?>" placeholder="Enter your state">

            <label>LGA:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="lga" value="<?php echo $lga; ?>" placeholder="Enter your LGA">

            <label>Nationality:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="nationality" value="<?php echo $nationality; ?>" placeholder="Enter your nationality">

            <label>Choose Class:</label><span class="w3-text-red">*</span>
            <select class="form-control w3-margin-bottom" name="programme">
              <option value="choose">-- choose --</option>
              <option value="JSSI">JSSI</option>
              <option value="JSS2">JSS2</option>
              <option value="JSS3">JSS3</option>
              <option value="SSS1">SSS1</option>
              <option value="SSS2">SSS2</option>
              <option value="SSS3">SSS3</option>
            </select>
            <label>School:</label><span class="w3-text-red">*</span>
            <input required class="form-control w3-margin-bottom" type="text" name="school" value="<?php echo $school; ?>" placeholder="Enter your School">
          </div>

          <div class="col-sm-12">
            <br>
            <input required class="btn btn-success form-control w3-hover-text-white" type="submit" name="signup" value="Signup">
          </div><hr>
        </form>
        </div>
      </div>
    </div>
  </article><hr>
    <!-- / content -->
    <!-- footer -->
    <footer>
      <div class="wrapper"> <a href="index.html" id="footer_logo"><span>E-</span>Maths</a>
      </div>
      <div class="wrapper">
        <nav>
          <ul id="footer_menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="app/studportal/login.php">Login</a></li>
            <li><a href="reg.php">Sign Up</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </nav>
        <div class="tel"><span>+234 70</span>6 896 9591</div>
      </div>
      <div id="footer_text" style="color: #fff;">Copyright &copy; <script>var y = new Date(); document.write(y.getFullYear()+" ");
      </script> 
        E-maths</strong> All rights reserved | Design by Umeoka Davis</div>
    </footer>
    <!-- / footer -->
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
 <script>
        $("#delsucs2").hide();
        $("#viewbtn").hide();
        $("#usereg").hide();
        $("#shobtn").on("click", function(){
          $("#usereg").show("slow");
        });
        $("#dhbtn").on("click", function(){
          $("#usereg").hide("slow");
        });
      </script>

      <?php
        if (isset($success)){
          ?>
          <script>
            setTimeout(function(){
                if ($('#delsucs').length > 0) {
                  $('#delsucs').fadeOut("slow");
                }
              }, 5000)   
          </script>
          <?php
        }
      ?>
      <?php
        if (isset($error)){
          ?>
          <script>
                  $('#usereg').show();   
          </script>
          <?php
        }
      ?>
</body>
</html>